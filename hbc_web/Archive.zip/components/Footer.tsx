export function Footer() {
  return (
    <footer className="mt-auto w-full py-4 text-center text-lg bg-[color:var(--color-card)] text-[color:var(--color-muted)]">
      Copyright © {new Date().getFullYear()} HBC, London
    </footer>
  );
}
